# JNOSQL-EMBED: Deprecated & Superseded Features

Features that were deprecated or explicitly removed to preserve the architectural integrity of JNOSQL-EMBED.

---

## 1. Raw StorageEngine Passing to Builder
- **Method**: `JunifyDBConfig.Builder.storageEngine(StorageEngine engine)`
- **Status**: Deprecated for removal (throws `UnsupportedOperationException`).
- **Rationale**: Passing a raw instantiated `StorageEngine` bypasses database lifecycle management, data directory assignment, and auto-flush interval configuration.
- **Replacement**: Use `JunifyDBConfig.Builder.storageEngine(StorageEngineType type)`.

---

## 2. Legacy Package `org.jnosql.embed.*`
- **Classes**: `org.jnosql.embed.quarkus.*`, `org.jnosql.embed.spring.*`
- **Status**: Removed in v1.0.0.
- **Rationale**: Created confusing package duality with `org.junify.db.*`.
- **Replacement**: Fully unified under `org.junify.db.quarkus.*` and `org.junify.db.spring.boot.*`.

---

## 3. SQL Relational Engine Bridging
- **Classes**: Former H2/SQLite relational bridge handlers.
- **Status**: Removed.
- **Rationale**: Bridging arbitrary SQL-92 relational joins over non-relational document and key-value structures created impedance mismatches and leaky abstractions.
- **Replacement**: JNOSQL-EMBED is positioned strictly as a multi-model NoSQL engine. Relational SQL queries belong in H2 or SQLite.
